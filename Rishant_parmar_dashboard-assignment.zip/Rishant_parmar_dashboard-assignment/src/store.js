import React from 'react';
import { create } from 'zustand'

const initialJSON = {
  categories: [
    {
      id: 1,
      name: 'CSPM Executive Dashboard',
      widgets: [
        { id: 101, name: 'Cloud Posture', text: 'text about posture risk' },
        { id: 102, name: 'Open Alerts', text: 'text about open alerts' },
        { id: 103, name: 'Compliance Score', text: 'text about compliance' }
      ]
    },
    {
      id: 2,
      name: 'KPI Overview',
      widgets: [
        { id: 201, name: 'MTTR', text: 'Mean time to resolve placeholder' },
        { id: 202, name: 'Deployments', text: 'Weekly deployments widget text' }
      ]
    }
  ]
}

let _id = 300
const nextId = () => ++_id

export const useDashboardStore = create((set, get) => ({
  categories: [],

  initFromJSON: (json) => set({ categories: json.categories }),

  addWidget: (categoryId, { name, text }) => set(state => ({
    categories: state.categories.map(cat => cat.id === categoryId
      ? { ...cat, widgets: [...cat.widgets, { id: nextId(), name, text }] }
      : cat)
  })),

  removeWidget: (categoryId, widgetId) => set(state => ({
    categories: state.categories.map(cat => cat.id === categoryId
      ? { ...cat, widgets: cat.widgets.filter(w => w.id !== widgetId) }
      : cat)
  })),


  setWidgetsForCategory: (categoryId, widgets) => set(state => ({
    categories: state.categories.map(cat => cat.id === categoryId
      ? { ...cat, widgets }
      : cat)
  }))
}))

export const useInitData = () => {
  const initFromJSON = useDashboardStore(s => s.initFromJSON)
  React.useEffect(() => {
    initFromJSON(initialJSON)
  }, [initFromJSON])
}

import React, { useMemo, useState } from 'react'
import Dashboard from './components/Dashboard'
import SearchBar from './components/SearchBar'
import CategoryManager from './components/CategoryManager'
import { useDashboardStore, useInitData } from './store'

export default function App(){
  useInitData()
  const [query, setQuery] = useState('')
  const [manageFor, setManageFor] = useState(null)
  const categories = useDashboardStore(s => s.categories)


  const filtered = useMemo(() => {
    if(!query.trim()) return categories
    const q = query.toLowerCase()
    return categories.map(cat => ({
      ...cat,
      widgets: cat.widgets.filter(w => w.name.toLowerCase().includes(q) || (w.text||'').toLowerCase().includes(q))
    }))
  }, [categories, query])

  return (
    <div className="container">
      <h1>Executive Dashboard</h1>
      <div className="toolbar">
        <SearchBar value={query} onChange={setQuery} />
        <span className="badge">JSON-driven • Add / Remove • Search</span>
      </div>

      {filtered.map(cat => (
        <div key={cat.id}>
          <div className="section">
            <h2>{cat.name}</h2>
            <div className="row">
              <button className="button" onClick={() => setManageFor(cat.id)}>Manage Widgets</button>
            </div>
          </div>
          <Dashboard categoryId={cat.id} widgets={cat.widgets} />
          <hr />
        </div>
      ))}

      {manageFor !== null && (
        <CategoryManager categoryId={manageFor} onClose={() => setManageFor(null)} />
      )}
    </div>
  )
}

import React from 'react'
import Widget from './Widget'
import AddWidgetForm from './AddWidgetForm'

export default function Dashboard({ categoryId, widgets }){
  return (
    <div>
      <div className="row" style={{marginBottom: 12}}>
        <AddWidgetForm categoryId={categoryId} />
      </div>
      <div className="grid">
        {widgets.length === 0 && <div className="small">No widgets in this category.</div>}
        {widgets.map(w => (
          <Widget key={w.id} categoryId={categoryId} widget={w} />
        ))}
      </div>
    </div>
  )
}

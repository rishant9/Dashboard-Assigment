import React from 'react'
import { useDashboardStore } from '../store'

export default function Widget({ categoryId, widget }){
  const removeWidget = useDashboardStore(s => s.removeWidget)
  return (
    <div className="card">
      <button className="x" title="Remove" onClick={() => removeWidget(categoryId, widget.id)}>✕</button>
      <h3>{widget.name}</h3>
      <p>{widget.text}</p>
    </div>
  )
}

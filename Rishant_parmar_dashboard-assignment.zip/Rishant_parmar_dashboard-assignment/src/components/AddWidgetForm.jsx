import React, { useState } from 'react'
import { useDashboardStore } from '../store'

export default function AddWidgetForm({ categoryId }){
  const addWidget = useDashboardStore(s => s.addWidget)
  const [open, setOpen] = useState(false)
  const [name, setName] = useState('')
  const [text, setText] = useState('')

  const submit = (e) => {
    e.preventDefault()
    if(!name.trim()) return
    addWidget(categoryId, { name, text })
    setName('')
    setText('')
    setOpen(false)
  }

  if(!open){
    return <button className="button accent" onClick={() => setOpen(true)}>+ Add Widget</button>
  }

  return (
    <form onSubmit={submit} className="row" style={{width: '100%'}}>
      <input className="input" placeholder="Widget name" value={name} onChange={e => setName(e.target.value)} />
      <input className="input" placeholder="Widget text" value={text} onChange={e => setText(e.target.value)} />
      <button className="button" type="submit">Add</button>
      <button className="button danger" type="button" onClick={() => setOpen(false)}>Cancel</button>
    </form>
  )
}

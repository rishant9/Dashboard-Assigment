import React, { useMemo, useState } from 'react'
import { useDashboardStore } from '../store'


export default function CategoryManager({ categoryId, onClose }){
  const { categories, setWidgetsForCategory } = useDashboardStore(s => ({
    categories: s.categories,
    setWidgetsForCategory: s.setWidgetsForCategory
  }))

  const category = categories.find(c => c.id === categoryId)
  const [checks, setChecks] = useState(() => Object.fromEntries(category.widgets.map(w => [w.id, true])))

  const list = category.widgets

  const save = () => {
    const kept = list.filter(w => checks[w.id])
    setWidgetsForCategory(categoryId, kept)
    onClose()
  }

  return (
    <div className="modal-backdrop">
      <div className="modal">
        <h3>Manage Widgets • {category.name}</h3>
        <div className="grid2">
          <div className="checkbox-list">
            {list.length === 0 && <div className="small">No widgets to manage.</div>}
            {list.map(w => (
              <label key={w.id} className="checkbox-item">
                <input
                  type="checkbox"
                  checked={!!checks[w.id]}
                  onChange={(e) => setChecks(prev => ({ ...prev, [w.id]: e.target.checked }))}
                />
                <div>
                  <div>{w.name}</div>
                  <div className="small">{w.text}</div>
                </div>
              </label>
            ))}
          </div>
          <div className="footer">
            <button className="button" onClick={onClose}>Close</button>
            <button className="button accent" onClick={save}>Save</button>
          </div>
        </div>
      </div>
    </div>
  )
}

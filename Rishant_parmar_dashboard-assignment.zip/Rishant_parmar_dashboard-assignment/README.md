This project implements the **Assignment For Frontend Trainees**:

- JSON-driven dashboard (categories -> widgets)
- Add widget (name + text) inside a category
- Remove widget via ❌ on the card
- Manage widgets via a **checkbox modal** (uncheck to remove from the category)
- Global search across widget *name* and *text*
- Local store management via **Zustand**

## Tech
- React 18
- Vite
- Zustand (local state management)
- Zero backend — all in-memory.

## Getting Started

# Install dependencies
npm install

# Start dev server
npm run dev


npm run build
npm run preview
